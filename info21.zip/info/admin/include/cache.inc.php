<?php
$admin_cache_array = array(
	"index"=>"首页",
	"info" => "分类信息",
	"about" => "其它"
);

$admin_cache = array(
	
	"index"=>array(
			"site"=>array("name"=>'网站首页')
			),
	
	"info"=>array(
			"list" => array("name"=>'信息列表页'),
			"info" => array("name"=>'信息内容页')
			),
	
	"about"=>array(
			"aboutus" => array("name"=>'站务-关于我们'),
			"announce" => array("name"=>'站务-网站公告'),
			"faq" => array("name"=>'站务-网站帮助'),
			"friendlink" => array("name"=>'站务-友情链接'),
			"sitemap" => array("name"=>'站务-网站地图'),
			"changecity" => array("name"=>'站务-切换分站'),
			)
);

$time_cache = array(
	'0'=>'关闭',
	'3600'=>'1小时',
	'10800'=>'3小时',
	'43200'=>'半天',
	'86400'=>'一天',
	'604800'=>'一周'
);
?>