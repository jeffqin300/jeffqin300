<?php
$info_do_type = array();

$info_do_type['惩罚相关'] = array(
	"违法内容",
	"与版规不符",
	"发布重复信息",
	"被举报太多"
);
							
$info_do_type['奖励相关'] = array(
	"优秀信息",
	"诚信商家"
);
?>