
<?php

$part = "news";
require_once( dirname( __FILE__ )."/comment.php" );
?>
