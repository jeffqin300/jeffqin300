<?php
$cityid=321;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>