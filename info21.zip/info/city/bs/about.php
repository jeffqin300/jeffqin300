<?php
$cityid=326;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>