<?php
$cityid=122;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>