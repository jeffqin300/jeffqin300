<?php
$cityid=226;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>