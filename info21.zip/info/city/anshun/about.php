<?php
$cityid=95;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>