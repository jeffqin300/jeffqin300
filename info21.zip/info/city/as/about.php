<?php
$cityid=207;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>