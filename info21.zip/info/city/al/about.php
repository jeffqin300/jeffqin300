<?php
$cityid=307;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>