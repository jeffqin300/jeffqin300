<?php
$cityid=87;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>